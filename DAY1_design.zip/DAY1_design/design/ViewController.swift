//
//  ViewController.swift
//  design
//
//  Created by MacStudent on 2018-02-20.
//  Copyright © 2018 kamal. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var iblEmail: UILabel!
    
    @IBOutlet weak var btnlogin: UIButton!
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var phoneno: UITextField!
    
    @IBOutlet weak var address: UITextField!
    @IBAction func actionloginbutton(_ sender: UIButton) {
        let email = txtEmail.text!
        iblEmail.text = email
        let infoalert = UIAlertController(title: "User Information", message: txtEmail.text!, preferredStyle: .actionSheet)
        
        infoalert.addAction(UIAlertAction(title: "Login", style: .default, handler: nil))
        
       infoalert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
       //  infoalert.addAction(UIAlertAction(title: "don't know", style: .cancel, handler: nil))
        self.present(infoalert, animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

