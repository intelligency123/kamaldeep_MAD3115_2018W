//
//  ViewController.swift
//  day2
//
//  Created by MacStudent on 2018-02-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class loginVC: UIViewController {

    @IBOutlet weak var emailtxt: UITextField!
    
    @IBOutlet weak var txtpassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   
    @IBAction func loginaction(_ sender: UIBarButtonItem) {
        let email = emailtxt.text
        let password = txtpassword.text
        
        if(email == "test" && password == "test"){
            
            let infoalert = UIAlertController(title: "login successful", message: "you are authenticated", preferredStyle: .alert)
            
            infoalert.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
            
            self.present(infoalert,animated: true, completion:  nil)
        }    }
    
    
    @IBAction func btnloginaction(_ sender: UIButton) {
        let email = emailtxt.text
        let password = txtpassword.text
        
        if(email == "test" && password == "test"){
            
            let infoalert = UIAlertController(title: "login successful", message: "you are authenticated", preferredStyle: .alert)
            
            infoalert.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
            
            self.present(infoalert,animated: true, completion:  nil)
        }
    }
   
    @IBAction func registeraction(_ sender: UIBarButtonItem) {
        let registerSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let registerVC = registerSB.instantiateViewController(withIdentifier: "RegistrationScreen")
        
        //self.present(registerVC, animated: true, completion: nil)
        navigationController?.pushViewController(registerVC, animated: true)
    }
}
    

    


