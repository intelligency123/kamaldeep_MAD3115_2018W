//
//  BookCell.swift
//  day 9
//
//  Created by Jigisha Patel on 2018-03-02.
//  Copyright © 2018 JK. All rights reserved.
//

import UIKit

class BookCell: UICollectionViewCell {
    
    @IBOutlet var lblBookTitle: UILabel!
    @IBOutlet var imgBook: UIImageView!
}
