//
//  registerVCViewController.swift
//  day3
//
//  Created by MacStudent on 2018-02-22.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class registerVCViewController: UIViewController ,UIPickerViewDelegate,UIPickerViewDataSource{
   
    
    
    
    @IBOutlet weak var txtemail: UITextField!
    
    @IBOutlet weak var txtcontactnumber: UITextField!
    
    @IBOutlet weak var txtpassword: UITextField!
    
    @IBOutlet weak var txtpostalcode: UITextField!
    
    @IBOutlet weak var txtname: UITextField!
    
    @IBOutlet weak var dateofbirth: UIDatePicker!
    
    @IBOutlet weak var citypicker: UIPickerView!
    var citylist: [String] = ["Vancouver","Ottawa","Toronto","Calgary","windsor","ajax","pickering","admenton","jasper","quebec","alberta","british columbia","montreal"]
    var selectedcityindex :Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()

        // add data in picker
        self.citypicker.delegate = self
        self.citypicker.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.title = "Register"
        
        let btnSubmit = UIBarButtonItem(title: "Submit", style: .plain, target: self, action: #selector(displayvalue))
        
        self.navigationItem.rightBarButtonItem = btnSubmit
    }
    @objc private func displayvalue(){
        self.selectedcityindex = self.citypicker.selectedRow(inComponent: 0)
        let alldata: String = "\(self.txtname.text!)\n\(self.txtcontactnumber.text!)\n\(self.dateofbirth.date)\n\(self.citylist[selectedcityindex])\n\(self.txtpostalcode.text!)\n\(self.txtemail.text!)\n\(self.txtpassword.text!)"
        
        //action sheet
        
        let infoalert = UIAlertController(title: "verify your detail", message: alldata, preferredStyle: .actionSheet)
        
        infoalert.addAction(UIAlertAction(title: "CANCEL", style: .default, handler: nil))
        infoalert.addAction(UIAlertAction(title: "CONFIRM", style: .default, handler: {_ in self.displaywelcomescreen()}))
        self.present(infoalert,animated: true,completion: nil)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
       return self.citylist.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row : Int,forComponent component: Int) -> String? {
        return self.citylist[row]
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
